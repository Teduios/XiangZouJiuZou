//
//  TrainModel.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/6.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseModel.h"
@class TrainListModel;
@class TrainListSeatinfosModel;
@class TT;
@interface TrainModel : BaseModel
@property(nonatomic,strong)TT *data;
@property(nonatomic,strong)NSString *error;
@end
@interface TT : BaseModel
@property(nonatomic,strong)NSMutableArray *trainList;
@property(nonatomic,strong)NSString *error;
@end
@interface TrainListModel : BaseModel
@property(nonatomic,strong)NSString *trainType;
@property(nonatomic,strong)NSString *trainNo;
@property(nonatomic,strong)NSString *from;
@property(nonatomic,strong)NSString *to;
@property(nonatomic,strong)NSString *startTime;
@property(nonatomic,strong)NSString *endTime;
@property(nonatomic,strong)NSString *duration;
@property(nonatomic,strong)NSMutableArray *seatInfos;
@end
@interface TrainListSeatinfosModel : BaseModel
@property(nonatomic,strong)NSString *seat;
@property(nonatomic,strong)NSString *seatPrice;
@property(nonatomic,strong)NSNumber *remainNum;


@end