//
//  CinemaController.m
//  hotle
//
//  Created by apple-jd31 on 15/11/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "CinemaController.h"
#import "CinemaCell.h"

@interface CinemaController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)NSTimer *timer;
@property(nonatomic)NSInteger idx;
@end

@implementation CinemaController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.timer =[NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(haha:) userInfo:nil repeats:YES];
    _idx=0;
    
}
-(void)haha:(NSTimer *)time
{
    if (![self.data.model.error isEqualToString:@"1"]) {
        [self.tableView reloadData];_idx=5;
    }
    if (_idx>4) {
        _idx=0;[self.timer invalidate];
    }
    NSLog(@"????%ld,%@",self.data.model.result.count,self.data.model);

}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.data.model.result.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CinemaCell *cell=[tableView dequeueReusableCellWithIdentifier:@"CCC" forIndexPath:indexPath];
    NSLog(@"%@,%ld,,%ld",self.data.model.result,self.data.model.result.count,indexPath.row);
    
   cell.cinemaName.text=[self.data getCinemaName:indexPath.row];
    cell.citiName.text=[self.data getCityName:indexPath.row];
    cell.trafficRoutes.text=[self.data getTrafficRoutes:indexPath.row];
    cell.distance.text=[NSString stringWithFormat:@"距离:%@",[self.data getDistance:indexPath.row].stringValue];
    cell.adress.text=[self.data getAdress:indexPath.row];
    cell.telephone.text=[self.data getTelephone:indexPath.row];
    switch (indexPath.row%6) {
        case 0:{cell.Image.image=[UIImage imageNamed:@"五彩1"];}; break;
        case 1:{cell.Image.image=[UIImage imageNamed:@"五彩2"];}; break;
        case 2:{cell.Image.image=[UIImage imageNamed:@"五彩3"];}; break;
        case 3:{cell.Image.image=[UIImage imageNamed:@"五彩4"];
            cell.adress.textColor=[UIColor blackColor];
            cell.telephone.textColor=[UIColor blackColor];
            cell.distance.textColor=[UIColor blackColor];
            cell.trafficRoutes.textColor=[UIColor blackColor];
            cell.cinemaName.textColor=[UIColor blackColor];
            cell.citiName.textColor=[UIColor blackColor];
        
        }; break;
        case 4:{cell.Image.image=[UIImage imageNamed:@"五彩5"];}; break;
        default:{cell.Image.image=[UIImage imageNamed:@"五彩6"];};break;}
   
    
    return cell;
}
















@end
