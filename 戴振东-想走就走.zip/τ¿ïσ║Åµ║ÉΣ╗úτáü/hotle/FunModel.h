//
//  FunModel.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/6.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseModel.h"
@class FunResultModel;
@interface FunModel : BaseModel
@property(nonatomic,strong)NSMutableArray *result;
@property(nonatomic,strong)NSString *error;
@property(nonatomic,strong)NSString *error2;
@end
@interface FunResultModel : BaseModel
@property(nonatomic,strong)NSString *address;//地址
@property(nonatomic,strong)NSString *allRemarks;//总评数
@property(nonatomic,strong)NSString *area;//区域
@property(nonatomic,strong)NSString *avgPrice;//人均消费
@property(nonatomic,strong)NSString *badRemarks;//差评
@property(nonatomic,strong)NSString *city;//城市
@property(nonatomic,strong)NSString *commonRemarks;//一般
@property(nonatomic,strong)NSString *environmentRating;//环境
@property(nonatomic,strong)NSString *good_remarks;//好评
@property(nonatomic,strong)NSString *latitude;//纬度
@property(nonatomic,strong)NSString *longitude;//经度
@property(nonatomic,strong)NSString *name;//名称
@property(nonatomic,strong)NSString *navigation;//导航
@property(nonatomic,strong)NSString *nearbyShops;//附近美食

@property(nonatomic,strong)NSString *photos;//图片

@property(nonatomic,strong)NSString *phone;//电话

@property(nonatomic,strong)NSString *productRating;//产品评分

@property(nonatomic,strong)NSString *recommendedProducts;//推荐产品
@property(nonatomic,strong)NSString *serviceRating;//服务
@property(nonatomic,strong)NSString *stars;//星级

@property(nonatomic,strong)NSString *tags;//标签

@end