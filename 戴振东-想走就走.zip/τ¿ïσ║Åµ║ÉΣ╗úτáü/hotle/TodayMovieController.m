//
//  TodayMovieController.m
//  hotle
//
//  Created by apple-jd31 on 15/11/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TodayMovieController.h"
#import "TodayMovieViewModel.h"
#import "TodayMovieCell.h"
#import <CoreLocation/CoreLocation.h>
#import "CinemaController.h"
#import <UIImageView+WebCache.h>
@interface TodayMovieController ()<UICollectionViewDelegateFlowLayout,CLLocationManagerDelegate>
@property(nonatomic,strong)TodayMovieViewModel *data;
@property(nonatomic)NSInteger idx;
@property(nonatomic,strong)NSTimer *timer;
@property(nonatomic,strong)CLLocationManager *manager;

@end

@implementation TodayMovieController
-(TodayMovieViewModel *)data
{
    if (!_data) {
        _data=[[TodayMovieViewModel alloc]initWithLongitude:@"113.262008" Latitude:@"23.103131"];
    }return _data;
}
-(CLLocationManager *)manager
{
    if (!_manager) {
        _manager=[[CLLocationManager alloc]init];
        _manager.delegate=self;
        _manager.desiredAccuracy=kCLLocationAccuracyBest;
        _manager.distanceFilter=1000.0f;
        [_manager requestAlwaysAuthorization];
       
        if ([UIDevice currentDevice].systemVersion.floatValue>=8.0) {
            [_manager requestAlwaysAuthorization];
            [_manager requestWhenInUseAuthorization];}
    
    }return _manager;
}


- (void)viewDidLoad {
    [super viewDidLoad];
   // NSLog(@"%@,%@",self.manager,self.data);
    [self.data getData];
   // [self.manager startUpdatingLocation];
//    self.timer=[NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(haha:) userInfo:nil repeats:YES];
//    _idx=0;
    [self.data addObserver:self forKeyPath:@"model.error2" options:NSKeyValueObservingOptionNew context:nil];
  //  NSLog(@"%@,,,%@",self.data,self.data.model);
    
}
-(void)haha:(NSTimer*)time
{
    if (![self.data.model.error isEqualToString:@"1"]) {
        [self.collectionView reloadData];_idx=5;
        NSLog(@"???ww?%ld",self.data.model.result.count);    }
    if (_idx>4) {
        _idx=0;
    [self.timer invalidate];
    }
    _idx++;NSLog(@"%ld第几次%@",_idx,self.data.model.error);
}

-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
    CLLocation *location=[locations objectAtIndex:0];
    self.data=[[TodayMovieViewModel alloc]initWithLongitude:[NSString stringWithFormat:@"%f",location.coordinate.latitude] Latitude:[NSString stringWithFormat:@"%f",location.coordinate.longitude]];
    [self.data getData];
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.data.model.result.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    TodayMovieCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SCell" forIndexPath:indexPath];
    cell.movieName.text=[self.data getMovieName:indexPath.row];
    
            [cell.moviePic sd_setImageWithURL:[NSURL URLWithString:[self.data getMoivePicURL:indexPath.row]]];
            
      
    
    switch (indexPath.row%9) {
            case 0:cell.moviePituce.image=[UIImage imageNamed:@"movie9"];break;
        case 1:{cell.movieName.textColor=[UIColor blackColor];cell.moviePituce.image=[UIImage imageNamed:@"movie8"];};break;
            case 2:cell.moviePituce.image=[UIImage imageNamed:@"movie7"];break;
        case 3:{cell.movieName.textColor=[UIColor blackColor];cell.moviePituce.image=[UIImage imageNamed:@"movie6"];}break;
            case 4:cell.moviePituce.image=[UIImage imageNamed:@"movie5"];break;
            case 5:cell.moviePituce.image=[UIImage imageNamed:@"movie4"];break;
        case 6:{cell.moviePituce.image=[UIImage imageNamed:@"movie3"];cell.movieName.textColor=[UIColor blackColor];};break;
        case 7:{cell.moviePituce.image=[UIImage imageNamed:@"movie2"];cell.movieName.textColor=[UIColor blackColor];};break;
            default:cell.moviePituce.image=[UIImage imageNamed:@"movie1"];break;
    }
    
    
    
    
    return cell;
}
-(UIEdgeInsets )collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(7,7,7,7);
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 7;
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 7;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    CGFloat width=(self.view.bounds.size.width-28)/3;
    CGFloat hight=(self.view.bounds.size.height-28)/3;
    return CGSizeMake(width, hight);
}



-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    CinemaController *vc=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"cinema"];
    
    vc.data=self.data.cinema;
    [self.navigationController pushViewController:vc animated:YES];
 
}
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    if ([object isKindOfClass:[TodayMovieViewModel class]]&&(![self.data.model.error isEqualToString:@"1"])) {
        //监听里要主线程才会刷新cell界面
       dispatch_async(dispatch_get_main_queue(), ^{
           [self.collectionView reloadData];
       });
       
    }
    


}
-(void)dealloc
{
   [self.data removeObserver:self forKeyPath:@"model.error2"];

}


@end
