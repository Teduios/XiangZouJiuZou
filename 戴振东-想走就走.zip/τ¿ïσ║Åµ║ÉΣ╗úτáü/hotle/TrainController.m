//
//  TrainController.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/10.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TrainController.h"
#import "TrainCell.h"
#import "TrainModel.h"
#import "TrainViewModel.h"
#import "TrainNetManager.h"
@interface TrainController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *date;

@property (weak, nonatomic) IBOutlet UITextField *startCity;

@property (weak, nonatomic) IBOutlet UITextField *endCity;
@property (weak, nonatomic) IBOutlet UITextField *year;
@property (weak, nonatomic) IBOutlet UITextField *month;
@property (weak, nonatomic) IBOutlet UITextField *day;

@property(nonatomic,strong)TrainViewModel *model;
@property (weak, nonatomic) IBOutlet UILabel *datee;
@property(nonatomic)NSInteger idx;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)NSTimer *timer;

@end

@implementation TrainController
-(TrainViewModel *)model{
    if (!_model) {
        _model=[[TrainViewModel alloc]initWithForm:@"广州" Date:@"2015-12-29" To:@"钦州"];
    }
    return _model;
}

- (IBAction)selct:(id)sender {
    if (self.startCity.text&&self.endCity.text&&self.year.text&&self.month.text&&self.day.text) {
        self.model.to=self.endCity.text;
        self.model.from=self.startCity.text;
        self.model.date=[self.year.text stringByAppendingFormat:@"-%@-%@",self.month.text,self.day.text];
        
    [self.model getData];

  }
    
    
    
    
    
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.model addObserver:self forKeyPath:@"modle.error" options:NSKeyValueObservingOptionNew context:nil];
   // NSLog(@"%@,,,,,,,,%@",self.model.modle.error,self.model);
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.model.modle.data.trainList.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TrainCell *cell=[tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    cell.startTime.text=[self.model getStartTime:indexPath.row];
    cell.endTime.text=[self.model getEndTime:indexPath.row];
    
    cell.duletion.text=[self.model getDuration:indexPath.row];
    cell.from.text=[self.model getFrom:indexPath.row];
    cell.to.text=[self.model getTo:indexPath.row];
   cell.seat1.text=[[self.model getSeatinfos1].remainNum.stringValue stringByAppendingString:[@"￥"stringByAppendingFormat:@"%@",[self.model getSeatinfos2].seatPrice]];
    cell.seat2.text=[[self.model getSeatinfos2].remainNum.stringValue stringByAppendingString:[@"￥"stringByAppendingFormat:@"%@",[self.model getSeatinfos1].seatPrice]];
    ;
    cell.image.image=[UIImage imageNamed:@"跑"];
    cell.Type.text=[self.model getTrainType:indexPath.row];
    cell.TrainNo.text=[self.model getTrainNo:indexPath.row];
    return cell;
}
//-(void)haha:(NSTimer *)timer{
//
////    if (![self.model.modle.data.error isEqualToString:@"1"]) {
////        self.date.text=[NSString stringWithFormat:@"日期:%@-%@-%@",self.year.text,self.month.text,self.day.text];
////        [self.tableView reloadData];_idx=3;
////    }
////    if (_idx>2) {
////        _idx=0;
////        [self.timer invalidate];}
////    _idx++;
//    
//    NSLog(@"%@,,,,,,,,",self.model.modle.error);
//    
//    
//}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    if ([object isKindOfClass:[TrainViewModel class]]&&(![self.model.modle.data.error isEqualToString:@"1"])) {
       dispatch_async(dispatch_get_main_queue(), ^{
           
         [self.tableView reloadData];
          //  [[NSNotificationCenter defaultCenter]postNotificationName:@"post" object:self userInfo:@{@"haha":@"你妹",@"ll":@"cool"}];
       });
        
    }
  //  NSLog(@"%@,?????,,,%@",object,self.model.modle.data.error);

}

-(void)dealloc
{
    [self.model removeObserver:self forKeyPath:@"modle.error"];
}

@end
