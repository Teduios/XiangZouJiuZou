//
//  FunViewModel.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/10.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import"FunModel.h"
#import "FunNetManager.h"
#define cc :(NSInteger)row;
#define dd -(NSString *)
@interface FunViewModel : NSObject
@property(nonatomic,strong)NSString *lotude;
@property(nonatomic,strong)NSString *longitude;
@property(nonatomic,strong)FunModel *model;
-(instancetype)initWithLongitude:(NSString *)longitude Lotude:(NSString *)lotuse;
-(void)getData;
-(NSString *)getAddress:(NSInteger)row;
-(NSString *)getAllRemarks:(NSInteger)row;
-(NSString *)getArea:(NSInteger)row;
-(NSString *)getAvgPrice:(NSInteger)row;
-(NSString *)getBadRemarks:(NSInteger)row;
-(NSString *)getCity cc;
-(NSString *)getCommonRemarks cc;
-(NSString *)getEnvironmentRating cc;
-(NSString *)getGood_remarks cc;
dd getName cc
dd getNavigation cc
dd getNearbyShops cc
dd getPhotos cc
dd getPhone cc
dd getProductRating cc
dd getRecommendedProducts cc
dd getServiceRating cc
dd getStars cc
dd getTags cc







@end
