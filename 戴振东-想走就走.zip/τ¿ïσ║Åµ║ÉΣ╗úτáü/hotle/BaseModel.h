//
//  BaseModel.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/4.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol BaseModelDelegate<NSObject>

@optional
+(id)input:(id)inputValue;

@end
@interface BaseModel : NSObject<BaseModelDelegate>//BaseModel遵守协议


-(NSDictionary *)speciaKey;

-(NSDictionary *)speciaModel;




@end
