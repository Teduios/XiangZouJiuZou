//
//  FunModel.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/6.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "FunModel.h"

@implementation FunModel
-(NSDictionary *)speciaModel
{
    return @{@"result":@"FunResultModel"};
}
-(NSMutableArray *)result
{
    if (!_result) {
        _result=[NSMutableArray new];
    }
    return _result;
}
@end
@implementation FunResultModel

-(NSDictionary *)speciaKey
{
    return @{@"all_remarks":@"allRemarks",@"avg_price":@"avgPrice",@"bad_remarks":@"badRemarks",@"common_remarks":@"commonRemarks",@"environment_rating":@"environmentRating",@"good_remarks":@"goodRemarks",@"nearby_shops":@"nearbyShops",@"product_rating":@"productRating",@"recommended_dishes":@"recommendedDishes",@"recommended_products":@"recommendedProducts",@"service_rating":@"serviceRating"};
    
}
@end