//
//  FunNetManager.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/6.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "FunModel.h"
@interface FunNetManager : BaseNetManager
+(id)getSomeFunOnLng:(NSString *)lng OnLat:(NSString *)lat completionHandle:(void(^)(FunModel *model,NSError *error))completionHandel;
@property(nonatomic,strong)FunModel *fun;
@end
