//
//  TraveModel.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/7.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TraveModel.h"

@implementation TraveModel
//-(TraveDataModel *)data
//{
//    if (!_data) {
//        _data=[TraveDataModel new];
//    }return _data;
//}
-(NSDictionary *)speciaModel
{
    return @{@"data":@"TraveDataModel"};
}

@end
@implementation TraveDataModel
-(NSDictionary *)speciaModel
{
    return @{@"books":@"TraveDataBookModel"};
}
-(NSMutableArray *)books
{
    if (!_books) {
        _books=[NSMutableArray new];
    }return _books;
}

@end
@implementation TraveDataBookModel



@end