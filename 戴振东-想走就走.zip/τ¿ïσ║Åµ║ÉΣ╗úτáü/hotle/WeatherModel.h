//
//  WeatherModel.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/4.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseModel.h"
@class WeatherResultModel;
@class WeatherResultSKModel;
@class WeatherFutureModel;
@class WeatherDaysModel;
@class WeatherDaysFutureModel;
@interface WeatherModel : BaseModel
@property(nonatomic,strong)NSNumber *resultcode;
@property(nonatomic,strong)NSString *reason;
@property(nonatomic,strong)WeatherResultModel *result;

@end
@interface WeatherResultModel:BaseModel
@property(nonatomic,strong)WeatherResultSKModel *sk;//当前
@property(nonatomic,strong)WeatherFutureModel *future;//未来
@end

@interface WeatherResultSKModel:BaseModel
@property(nonatomic,strong)NSString *temp;//温度
@property(nonatomic,strong)NSString *windDirection;//风向
@property(nonatomic,strong)NSString *windStrength;//风力
@property(nonatomic,strong)NSString *humidity;//当前湿度
@property(nonatomic,strong)NSString *time;//更新时间
@end
@interface WeatherFutureModel : BaseModel
@property(nonatomic,strong)NSString *day1;
@property(nonatomic,strong)NSString *day2;
@property(nonatomic,strong)NSString *day3;
@property(nonatomic,strong)NSString *day4;
@property(nonatomic,strong)NSString *day5;
@property(nonatomic,strong)NSString *day6;
@property(nonatomic,strong)NSString *day7;
@property(nonatomic,strong)WeatherDaysModel *day11;
@property(nonatomic,strong)WeatherDaysModel *day22;
@property(nonatomic,strong)WeatherDaysModel *day33;
@property(nonatomic,strong)WeatherDaysModel *day44;
@property(nonatomic,strong)WeatherDaysModel *day55;
@property(nonatomic,strong)WeatherDaysModel *day66;
@property(nonatomic,strong)WeatherDaysModel *day77;

@end
@interface WeatherDaysModel : BaseModel
@property(nonatomic,strong)NSString *date;//时间
@property(nonatomic,strong)NSString *temperature;//温度区间
@property(nonatomic,strong)NSString *weather;//天气
@property(nonatomic,strong)NSString *week;//星期
@property(nonatomic,strong)NSString *wind;//风

@end
