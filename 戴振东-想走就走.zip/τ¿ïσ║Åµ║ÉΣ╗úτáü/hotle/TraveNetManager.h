//
//  TraveNetManager.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/7.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "TraveModel.h"
@interface TraveNetManager : BaseNetManager
+(id)getTraveDataFoQuery:(NSString *)query Page:(NSString*)page completionHandle:(void(^)(TraveModel *modle,NSError *error))completionHandle;


@end
