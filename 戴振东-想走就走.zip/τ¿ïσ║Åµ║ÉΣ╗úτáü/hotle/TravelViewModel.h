//
//  TravelViewModel.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import"TraveModel.h"
#import "TraveNetManager.h"
#define cc -(NSString *)
#define dd :(NSInteger)row;
@interface TravelViewModel : NSObject
-(instancetype)initWithQuery:(NSString *)query Page:(NSString *)page;
-(void)getData;
@property(nonatomic,strong)NSString *query;
@property(nonatomic,strong)NSString *page;
@property(nonatomic,strong)TraveModel *model;
-(NSString *)getheadImage:(NSInteger)row;
cc getBookUrl dd
cc getTitle dd

cc getUserHeadImg dd
cc getStartTime dd
-(NSNumber*)getRouteDays dd




cc getText dd





@end
