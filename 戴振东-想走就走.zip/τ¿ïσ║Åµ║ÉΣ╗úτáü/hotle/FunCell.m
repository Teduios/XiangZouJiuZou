//
//  FunCell.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/10.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "FunCell.h"

@implementation FunCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
