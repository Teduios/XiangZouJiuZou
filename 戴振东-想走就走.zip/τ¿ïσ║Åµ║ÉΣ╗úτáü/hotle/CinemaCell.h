//
//  CinemaCell.h
//  hotle
//
//  Created by apple-jd31 on 15/11/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CinemaCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *cinemaName;
@property (weak, nonatomic) IBOutlet UILabel *citiName;
@property (weak, nonatomic) IBOutlet UILabel *adress;

@property (weak, nonatomic) IBOutlet UILabel *trafficRoutes;
@property (weak, nonatomic) IBOutlet UILabel *telephone;
@property (weak, nonatomic) IBOutlet UILabel *distance;
@property (weak, nonatomic) IBOutlet UIImageView *Image;


@end
