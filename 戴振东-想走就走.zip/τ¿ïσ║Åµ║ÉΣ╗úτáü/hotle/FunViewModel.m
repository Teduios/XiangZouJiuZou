//
//  FunViewModel.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/10.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "FunViewModel.h"
#define q FunResultModel *m=self.model.result[row];return
@implementation FunViewModel
//-(FunModel *)model
//{
//    if (!_model) {
//        _model=[[FunModel alloc]init];
//    }return _model;
//}
-(instancetype)initWithLongitude:(NSString *)longitude Lotude:(NSString *)lotuse
{
    if (self=[super init]) {
        _longitude=longitude;_lotude=lotuse;
    }return self;
}
-(void)getData
{
[FunNetManager getSomeFunOnLng:self.longitude OnLat:self.lotude completionHandle:^(FunModel *model, NSError *error) {
    self.model=model;}];
}
-(NSString *)getTags:(NSInteger)row
{
    FunResultModel *m=self.model.result[row];
    return m.tags;
}
-(NSString *)getStars:(NSInteger)row
{
    q m.stars;
}
-(NSString *)getServiceRating:(NSInteger)row
{
    q m.serviceRating;
}
-(NSString *)getRecommendedProducts:(NSInteger)row
{
    q m.recommendedProducts;
}
-(NSString *)getProductRating:(NSInteger)row
{
    q m.productRating;
}
-(NSString *)getPhotos:(NSInteger)row
{
    q m.photos;
}
-(NSString *)getPhone:(NSInteger)row
{
    q m.phone;
}
-(NSString *)getNearbyShops:(NSInteger)row
{
    q m.nearbyShops;
}
-(NSString *)getNavigation:(NSInteger)row
{
    q m.navigation;
}
-(NSString *)getName:(NSInteger)row
{
    q m.name;
}
-(NSString *)getCity:(NSInteger)row
{
    q m.city;
}
-(NSString *)getCommonRemarks:(NSInteger)row
{
    q m.commonRemarks;
}
-(NSString *)getGood_remarks:(NSInteger)row
{
    q m.good_remarks;
}
-(NSString *)getEnvironmentRating:(NSInteger)row
{
    q m.environmentRating;
}
-(NSString *)getBadRemarks:(NSInteger)row
{
    q m.badRemarks;
}
-(NSString *)getAvgPrice:(NSInteger)row
{
    q m.avgPrice;
}
-(NSString *)getArea:(NSInteger)row
{
    q m.area;
}
-(NSString *)getAllRemarks:(NSInteger)row
{
    q m.allRemarks;
}
-(NSString *)getAddress:(NSInteger)row
{
    q m.address;
}


@end
