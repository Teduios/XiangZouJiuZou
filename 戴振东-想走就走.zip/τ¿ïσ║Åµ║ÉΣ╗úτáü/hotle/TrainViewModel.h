//
//  TrainViewModel.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/9.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TrainModel.h"
#import "TrainNetManager.h"

@interface TrainViewModel : NSObject
-(instancetype)initWithForm:(NSString *)form Date:(NSString *)date To:(NSString *)to;
@property(nonatomic,strong)TrainModel *modle;
@property(nonatomic,strong)NSString *date;
@property(nonatomic,strong)NSString *to;
@property(nonatomic,strong)NSString *from;

-(void)getData;
-(NSString *)getTrainType:(NSInteger)row;
-(NSString *)getTrainNo:(NSInteger)row;
-(NSString *)getFrom:(NSInteger)row;
-(NSString *)getTo:(NSInteger)row;
-(NSString *)getStartTime:(NSInteger)row;
-(NSString *)getDuration:(NSInteger)row;
-(NSString *)getEndTime:(NSInteger)row;
-(TrainListSeatinfosModel *)getSeatinfos1;
-(TrainListSeatinfosModel *)getSeatinfos2;
@end
