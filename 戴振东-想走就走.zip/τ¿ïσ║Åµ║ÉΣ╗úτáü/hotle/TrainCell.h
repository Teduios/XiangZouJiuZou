//
//  TrainCell.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/10.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *from;
@property (weak, nonatomic) IBOutlet UILabel *to;
@property (weak, nonatomic) IBOutlet UILabel *Type;
@property (weak, nonatomic) IBOutlet UILabel *TrainNo;
@property (weak, nonatomic) IBOutlet UILabel *seat1;
@property (weak, nonatomic) IBOutlet UILabel *seat2;
@property (weak, nonatomic) IBOutlet UILabel *startTime;
@property (weak, nonatomic) IBOutlet UILabel *endTime;
@property (weak, nonatomic) IBOutlet UILabel *duletion;
@property (weak, nonatomic) IBOutlet UIImageView *image;




@end
