//
//  TraveNetManager.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/7.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TraveNetManager.h"

@implementation TraveNetManager
+(id)getTraveDataFoQuery:(NSString *)query Page:(NSString *)page completionHandle:(void (^)(TraveModel *, NSError *))completionHandle
{
NSString *url=@"http://apis.baidu.com/qunartravel/travellist/travellist";
NSString *APPKEY=@"66b69f95adecd087bb73755538f9142a";
    NSString *Q=[NSString stringWithFormat:@"%@?query=%@&page=%@",url,[query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],page];
    NSString *qq=[Q stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *requet=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:qq] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10];
  //  NSLog(@"这是%@",qq);
    [requet setHTTPMethod:@"GET"];
    
    [requet addValue:APPKEY forHTTPHeaderField:@"apikey"];
    [requet addValue:[query stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] forHTTPHeaderField:@"query"];
    [requet addValue:page forHTTPHeaderField:@"page"];
    
    [NSURLConnection sendAsynchronousRequest:requet queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        if (connectionError) {
            NSLog(@"连接失败%@",connectionError);
        }else{
            NSData *da=[NSJSONSerialization JSONObjectWithData:data options:NSJapaneseEUCStringEncoding|NSJSONReadingAllowFragments|NSJSONReadingMutableContainers|NSJSONReadingMutableLeaves|NSJSONWritingPrettyPrinted error:nil];
        //  NSLog(@"%@====data",da);
            TraveModel *trave=[TraveModel input:da];
            completionHandle(trave,nil);
        }
    }];
    return nil;
}

@end
