//
//  BaseNetManager.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/5.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseNetManager : NSObject
+(id)getDataForNet:(NSString*)dataURL completiaonHandle:(void(^)(NSData *data,NSError *error))completionHandle;


@end
