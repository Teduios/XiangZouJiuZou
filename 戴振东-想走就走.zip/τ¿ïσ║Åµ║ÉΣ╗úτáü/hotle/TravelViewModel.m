//
//  TravelViewModel.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TravelViewModel.h"
#define t   TraveDataBookModel *model=self.model.data.books[row];return model.
@implementation TravelViewModel
-(TraveModel *)model
{
    if (!_model) {
        _model=[[TraveModel alloc]init];
    }return _model;

}
-(instancetype)initWithQuery:(NSString *)query Page:(NSString *)page
{
    if (self=[super init]) {
        _query=query;_page=page;
    }return self;
}
-(void)getData
{[TraveNetManager getTraveDataFoQuery:self.query Page:self.page completionHandle:^(TraveModel *modle, NSError *error) {
   // NSLog(@"%@,,,,,,%@",_query,_page);
    self.model=modle;
}];//NSLog(@"%@,,,,,,%@",_query,_page);
}
-(NSString *)getUserHeadImg:(NSInteger)row
{
    TraveDataBookModel *model=self.model.data.books[row];
    return model.userHeadImg;
}
-(NSString *)getTitle:(NSInteger)row
{
    t title;
}
-(NSString *)getText:(NSInteger)row
{
    t text;
}
-(NSString *)getStartTime:(NSInteger)row
{
    t startTime;
}
-(NSNumber *)getRouteDays:(NSInteger)row
{
    t routeDays;
}
-(NSString *)getheadImage:(NSInteger)row
{
    t headImage;
}
-(NSString *)getBookUrl:(NSInteger)row
{
    t bookUrl;
}

@end
