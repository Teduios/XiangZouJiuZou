//
//  futrueWeatherCell.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/9.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "futrueWeatherCell.h"

@implementation futrueWeatherCell

-(instancetype)init
{
    if (self=[super init]) {
        self.separatorInset=UIEdgeInsetsMake(100,200, 10, 10);
    }
    return self;
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

@end
