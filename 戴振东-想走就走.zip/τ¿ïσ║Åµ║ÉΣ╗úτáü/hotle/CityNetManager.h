//
//  CityNetManager.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/8.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "MovieModel.h"
@interface CityNetManager : BaseNetManager
+(id)getCityList:(void(^)(CityName *model,NSError *error))completionHandle;
@end
