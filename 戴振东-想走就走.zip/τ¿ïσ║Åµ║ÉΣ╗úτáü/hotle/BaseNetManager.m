//
//  BaseNetManager.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/5.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseNetManager.h"

@implementation BaseNetManager
+(id)getDataForNet:(NSString *)dataURL completiaonHandle:(void (^)(NSData *data, NSError *error))completionHandle
{

NSURLSessionDataTask *da=[[NSURLSession sharedSession]dataTaskWithURL:[NSURL URLWithString:dataURL] completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
 // NSLog(@"???%@",data);
   
  NSData *n=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers|NSJSONReadingMutableLeaves|NSJSONReadingAllowFragments|NSJapaneseEUCStringEncoding|NSJSONWritingPrettyPrinted error:&error];
    
  //  NSStringEncoding gbkEncoding = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
   // 使用如下方法 将获取到的数据按照gbkEncoding的方式进行编码，结果将是正常的汉字
  //  NSString *zhuanHuanHouDeShuJu = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
   // NSLog(@"obj=%@,zhuan%@",n,zhuanHuanHouDeShuJu);
   // NSDictionary *fd=@{@"result":@""};
    
    completionHandle(n,error);
}];
    [da resume];
    return da;
}
@end
