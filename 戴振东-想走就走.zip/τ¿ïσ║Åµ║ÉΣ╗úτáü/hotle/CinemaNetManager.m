//
//  CinemaNetManager.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/8.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "CinemaNetManager.h"

@implementation CinemaNetManager

+(id)getCinemaForLatitude:(NSString *)latitude Longitude:(NSString *)longitude Radius:(NSString *)radius CompletionHandle:(void (^)(CinemaModel *, NSError *))completionHandle
{
    NSString *url=[NSString stringWithFormat:@"http://v.juhe.cn/movie/cinemas.local?key=e9421b9d9c66bc95ff7696dbc9e04a60&dtype=json&lat=%@&lon=%@&radius=%@",latitude,longitude,radius];
    return [self getDataForNet:url completiaonHandle:^(NSData *data, NSError *error) {
        CinemaModel *cinema=[CinemaModel input:data];
        completionHandle(cinema,error);
    
    }];
        
        
    
 }

@end
