//
//  MovieModel.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/8.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "MovieModel.h"

@implementation CinemaModel
-(NSDictionary *)speciaModel{
    return @{@"result":@"CinemaListModel"};
}
@end
@implementation CinemaListModel

-(NSDictionary *)speciaKey{
    return @{@"id":@"iid"};
}
@end
@implementation CityName
-(NSMutableArray *)result{
    if (!_result) {
        _result=[NSMutableArray new];
    }
    return _result;
}
-(NSDictionary *)speciaModel
{
    return @{@"result":@"CityNameListModel"};
}

@end
@implementation CityNameListModel
-(NSDictionary *)speciaKey{
    return @{@"id":@"iid",@"city_name":@"cityName",@"city_pre":@"cityPre",@"city_pinyin":@"cityPinyin",@"city_short":@"cityShort"};

}

@end
@implementation TodayMovie
-(NSMutableArray *)result{
    if (!_result) {
        _result=[NSMutableArray new];
    }return _result;
}
-(NSDictionary *)speciaModel
{
    return @{@"result":@"TodayMovieList"};
}
@end
@implementation TodayMovieList

-(NSDictionary *)speciaKey{
    
    return @{@"pic_url":@"picUrl"};
}

@end

