//
//  FunNetManager.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/6.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "FunNetManager.h"

@implementation FunNetManager
+(id)getSomeFunOnLng:(NSString *)lng OnLat:(NSString *)lat completionHandle:(void (^)(FunModel *model, NSError *error))completionHandel
{

    return [self getDataForNet:[NSString stringWithFormat:@"http://apis.juhe.cn/catering/query?key=099641f9f0350319fd750f40e1a4f686&lng=%@&lat=%@&radius=2000",lng,lat]completiaonHandle:^(NSData *data, NSError *error) {
        FunModel *fun=[FunModel input:data];
        FunNetManager *f=[self new];
        f.fun=fun;
//                   NSLog(@"%@dadad",fun.result.area);
       
        completionHandel(fun,error);
    }];;


}


@end
