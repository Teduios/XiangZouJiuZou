//
//  TravelCell.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TravelCell.h"

@implementation TravelCell
- (IBAction)select:(id)sender {
    
    
}
- (IBAction)sharea:(id)sender {
    NSLog(@"??????");
    
}

- (void)awakeFromNib {
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    
}

@end
