//
//  TrainNetManager.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/6.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "TrainModel.h"
@interface TrainNetManager : BaseNetManager
+(id)getBaseModle:(NSString *)version From:(NSString *)from To:(NSString *)to Date:(NSString *)date
 completionHandle:(void(^)(TrainModel* modle,NSError *error))completionHandle;

@end
