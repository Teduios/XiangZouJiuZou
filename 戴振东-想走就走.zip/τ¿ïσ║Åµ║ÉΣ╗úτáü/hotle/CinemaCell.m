//
//  CinemaCell.m
//  hotle
//
//  Created by apple-jd31 on 15/11/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "CinemaCell.h"

@implementation CinemaCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
