//
//  TRavelController.m
//  hotle
//
//  Created by apple-jd31 on 15/11/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TRavelController.h"
#import "TravelCell.h"
#import "TravelViewModel.h"
#import "TrainNetManager.h"
#import <Masonry.h>
#import "WeatherController.h"
#import <SDImageCache.h>
#import <UIImageView+WebCache.h>
#import <FBShimmeringLayer.h>
#import <FBShimmeringView.h>
#import "FunController.h"
#import "TodayMovieController.h"
#import "TrainController.h"
#import "moreController.h"

@interface TRavelController ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)TravelViewModel *data;
@property (weak, nonatomic) IBOutlet UITextField *input;
@property(nonatomic,strong)UIImageView *img;

@property (weak, nonatomic) IBOutlet UIScrollView *scroView;

@property(nonatomic,strong)NSMutableArray *imageArr;
@property(nonatomic,strong)UIView *greenView;
@property(nonatomic,strong)UIButton *funBut;
@property(nonatomic,strong)UIButton *weatherBut;
@property(nonatomic,strong)UIButton *movieBut;
@property(nonatomic,strong)UIButton *trainBut;
@property (weak, nonatomic) IBOutlet UIView *blue;
@property(nonatomic,strong)UITextField *weatherText;
@property(nonatomic,strong)NSTimer *time;
@property(nonatomic,strong)UIPageControl *page;
@property(nonatomic)NSInteger idx;

@end

@implementation TRavelController

-(UIButton *)funBut
{
    if (!_funBut) {
        _funBut=[[UIButton alloc]init];
    }return _funBut;
}
-(UIButton *)weatherBut
{
    if (!_weatherBut) {
        _weatherBut=[[UIButton alloc]init];
    }return _weatherBut;
}
-(UIButton *)movieBut
{
    if (!_movieBut) {
        _movieBut=[[UIButton alloc]init];
    }return _movieBut;
}
-(UIButton *)trainBut
{
    if (!_trainBut) {
        _trainBut=[[UIButton alloc]init];
    }return _trainBut;
}
-(UITextField *)weatherText
{
    if (!_weatherText) {
        _weatherText=[[UITextField alloc]init];
    }return _weatherText;
}

-(TravelViewModel *)data
{
    if (!_data) {
        _data=[[TravelViewModel alloc]initWithQuery:@"桂林" Page:@"20"];
    }return _data;
}

- (IBAction)select:(id)sender {
    self.data.query=_input.text;
    [self.data getData];
    NSLog(@"%@",_input.text);
    [[UINavigationBar appearance]setBackgroundImage:[UIImage imageNamed:@"五彩1"] forBarMetrics:UIBarMetricsDefault];
    [self.view endEditing:YES];
   // self.tableView.hidden=YES;
  //  NSLog(@"addddddddddddd");
    

}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.data getData];
    self.scroView.delegate=self;
    self.scroView.pagingEnabled=YES;
    self.scroView.scrollEnabled=YES;
  
    [self.blue mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    _idx=0;

    //使用类中有类的KVO要注意每一个类都要写懒加载否则类中的类为nil
    [self.data addObserver:self forKeyPath:@"model.error" options:NSKeyValueObservingOptionNew context:nil];
    _input.backgroundColor=[UIColor grayColor];
    _input.textColor=[UIColor whiteColor];
    _input.text=@"旅游关键字";
    self.greenView =[[UIView alloc]init];
    // self.greenView.hidden=YES;
    [self.view addSubview:self.greenView];
   
  /////////////////////////////附近吃喝
    
   /////////////////////////
    
    UISwipeGestureRecognizer *right=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(right:)];
    right.direction=UISwipeGestureRecognizerDirectionRight;
    
   [self.tableView addGestureRecognizer:right];
    UISwipeGestureRecognizer *left=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(left:)];
    left.direction=UISwipeGestureRecognizerDirectionLeft;
    [self.tableView addGestureRecognizer:left];

    UITextField *t=[[UITextField alloc]init];
    t.frame=CGRectMake(100,100,100, 100);
    [self.view addSubview:t];
    
 
    self.time=[NSTimer scheduledTimerWithTimeInterval:1.67 target:self selector:@selector(haha:) userInfo:nil repeats:YES];
    _page=[[UIPageControl alloc]init];
    [self.view addSubview:_page];
    [_page mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.scroView.mas_right).mas_equalTo(-5);
        make.bottom.mas_equalTo(self.scroView.mas_bottom).mas_equalTo(-5);
        make.width.mas_equalTo(100);
        make.height.mas_equalTo(10);
        
    }];
    _page.numberOfPages=5;
    _page.userInteractionEnabled=NO;
  
    
  //  [UIApplication sharedApplication].statusBarStyle=UIStatusBarStyleDefault;
    
}



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.data.model.data.books.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TravelCell *cell=[tableView dequeueReusableCellWithIdentifier:@"CC" forIndexPath:indexPath];
    if (![self.data.model.data.error isEqualToString:@"1"]) {
        cell.text.text=[self.data getText:indexPath.row];
        cell.title.text=[self.data getTitle:indexPath.row];
        cell.startTime.text=[self.data getStartTime:indexPath.row];
        cell.routeDays.text=[NSString stringWithFormat:@"旅程时常:%@",[self.data getRouteDays:indexPath.row].stringValue];
        NSString *path=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"image"];
        
        NSFileManager *file=[NSFileManager defaultManager];
        if (![file fileExistsAtPath:path]) {
            [file createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];}
        
        [cell.headImage sd_setImageWithURL:[NSURL URLWithString:[self.data getheadImage:indexPath.row]]];
        [cell.ueserImage sd_setImageWithURL:[NSURL URLWithString:[self.data getUserHeadImg:indexPath.row]]];
    }
    return cell;
}
-(void)right:(UISwipeGestureRecognizer *)right
{
    _funBut.hidden=NO;_trainBut.hidden=NO;_movieBut.hidden=NO;_weatherBut.hidden=NO;
     _img.alpha=0;
    _weatherText.hidden=NO;
    _input.hidden=NO;
  //  self.greenView.hidden=NO;
    _funBut.alpha=0;_trainBut.alpha=0;_movieBut.alpha=0;_weatherBut.alpha=0;
    [UIView animateKeyframesWithDuration:0.4 delay:0 options:YES animations:^{
        self.greenView.frame=CGRectMake(0,0,self.view.bounds.size.width/2,self.view.bounds.size.height);
        self.blue.frame=CGRectMake(self.view.bounds.size.width/2,0,self.view.frame.size.width, self.view.frame.size.height);
        _img.alpha=1;
        _input.alpha=1;
        _funBut.alpha=1;_trainBut.alpha=1;_movieBut.alpha=1;_weatherBut.alpha=1;
        _weatherText.alpha=1;
      
        
        
    } completion:nil];
    
    
}
-(void)left:(UISwipeGestureRecognizer* )left
{
    _funBut.alpha=0;_weatherBut.alpha=0;_movieBut.alpha=0;_weatherBut.alpha=0;
  
    _funBut.hidden=YES;_trainBut.hidden=YES;_movieBut.hidden=YES;_weatherBut.hidden=YES;
    [UIView animateKeyframesWithDuration:0.3 delay:0 options:YES animations:^{
        self.blue.frame=CGRectMake(0, 0,self.view.bounds.size.width,self.view.bounds.size.height);
        self.greenView.frame=CGRectMake(0,0,0,self.view.bounds.size.height);
        
        
    } completion:nil];
 _weatherText.text=@"北京";
    _weatherText.alpha=0;
    
    
}
-(void)weather:(UIButton*)but//
{
    WeatherController *wv=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"weather"];
    wv.cityName=_weatherText.text;
    [self.navigationController pushViewController:wv animated:YES];
    
}
-(void)movie:(UIButton *)but
{
    TodayMovieController *today=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"todaymovie"];
    [self.navigationController pushViewController:today animated:YES];

}
-(void)train:(UIButton *)but
{
    TrainController *train=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"train"];
    [self.navigationController pushViewController:train animated:YES];
}
-(void)fun:(UIButton *)but
{
    FunController *fun=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"fun"];
    [self.navigationController pushViewController:fun animated:YES];
    
    
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    
    if ([object isKindOfClass:[TravelViewModel class]]&&(![self.data.model.data.error isEqualToString:@"1"])) {
        dispatch_async(dispatch_get_main_queue(), ^{
         //   self.tableView.hidden=NO;
            [self.tableView reloadData];
         //   [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aaaa:) name:@"post" object:nil];
        });[self aa];
        
    }
    
}

-(void)aa
{
  
    //取硬盘程序根目录
    NSInteger ii=5;
    if (ii>self.data.model.data.books.count) {
        ii=self.data.model.data.books.count;
    }
    CGSize size=self.scroView.frame.size;
    size.width=size.width*5;
    self.scroView.contentSize=size;
    for (int i=0; i<ii; i++) {
        UIImageView *img=[[UIImageView alloc]initWithFrame:CGRectMake(self.view.frame.size.width*i,0,self.view.frame.size.width, size.height)];
        [img sd_setImageWithURL:[NSURL URLWithString:[self.data getheadImage:i]]];
        [self.scroView addSubview:img];
        UILabel *lable=[[UILabel alloc]initWithFrame:CGRectMake((self.view.frame.size.width*i)+self.view.frame.size.width/2.5,size.height/3,self.view.frame.size.width-self.view.frame.size.width/2.5,size.height/0.9)];
        lable.text=[self.data getTitle:i];
        lable.textColor=[UIColor whiteColor];
        lable.textAlignment=UIControlContentHorizontalAlignmentRight;
        [self.scroView addSubview:lable];
        
    }
   

}


-(void)dealloc
{
    [self.data removeObserver:self forKeyPath:@"model.error"];

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
 moreController *more=[[moreController alloc]init];
    if (![self.data.model.data.error isEqualToString:@"1"]) {
        more.url=[self.data getBookUrl:indexPath.row];
        [self.navigationController pushViewController:more animated:YES];
        [self.time invalidate];
        
    }
    
}
-(void)haha:(NSTimer*)time
{
   // NSLog(@":sssssssssssssssssss");
   
    if (self.scroView.contentOffset.x>=(4*self.view.frame.size.width)) {
        self.scroView.contentOffset=CGPointMake(0,0);
    }else{
        self.scroView.contentOffset=CGPointMake(self.scroView.contentOffset.x+self.view.frame.size.width,0);}
    _page.currentPage=self.scroView.contentOffset.x/self.view.frame.size.width;
    if (_page.currentPage>5) {
        _page.currentPage=0;
    }
    if (self.img!=nil){
        return;
    }else {
      //  NSLog(@"haaaaaahhhhhhhhhhhhhhhhhhhhhhhhaaaaaaa");
    
    
    self.img=[[UIImageView  alloc] initWithImage:[UIImage imageNamed:@"诶"]];
    [self.greenView addSubview:_img];
    [_img mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    FBShimmeringView *v4=[FBShimmeringView new];
    [_greenView addSubview:v4];
    [v4 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.greenView.mas_bottom).mas_equalTo(-110);
        make.width.mas_equalTo(130);
        make.height.mas_equalTo(50);
        make.left.mas_equalTo(self.greenView.mas_left).mas_equalTo(30);
    }];
    v4.contentView=self.funBut;
    [_funBut mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    v4.shimmering=YES;
    [_funBut setTitle:@"查看附近吃喝" forState:UIControlStateNormal];
    [_funBut addTarget:self action:@selector(fun:) forControlEvents:UIControlEventTouchUpInside];
    [_funBut setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    //////////////////////////天气
    [self.greenView addSubview:self.weatherText];
    [_weatherText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(_greenView.mas_bottom).mas_equalTo(-363);
        make.width.mas_equalTo(70);
        make.height.mas_equalTo(20);
        make.left.mas_equalTo(_greenView.mas_left).mas_equalTo(30);
        
    }];
    
    _weatherText.text=@"城市名";
    _weatherText.textColor=[UIColor grayColor];
    // _weatherText.backgroundColor=[UIColor yellowColor];
    FBShimmeringView *v1=[FBShimmeringView new];
    [self.greenView addSubview:v1];
    [v1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(_greenView.mas_bottom).mas_equalTo(-350);
        make.width.mas_equalTo(75);
        make.height.mas_equalTo(50);
        make.left.mas_equalTo(_greenView.mas_left).mas_equalTo(80);
        
    }];
    v1.contentView=self.weatherBut;
    v1.shimmering=YES;
    [_weatherBut mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    
    
    [_weatherBut setTitle:@"查询天气" forState:UIControlStateNormal];
    
    [_weatherBut addTarget:self action:@selector(weather:) forControlEvents:UIControlEventTouchUpInside];
    [_weatherBut setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    //////////////////////////火车票
    FBShimmeringView *v3=[FBShimmeringView new];
    [self.greenView addSubview:v3];
    
    
    [v3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(_greenView.mas_bottom).mas_equalTo(-270);
        make.width.mas_equalTo(130);
        make.height.mas_equalTo(50);
        make.left.mas_equalTo(_greenView.mas_left).mas_equalTo(30);
    }];
    v3.contentView=self.trainBut;
    [_trainBut mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    [_trainBut addTarget:self action:@selector(train:) forControlEvents:UIControlEventTouchUpInside];
    
    //_trainBut.backgroundColor=[UIColor grayColor];
    [_trainBut setTitle:@"查询火车售票" forState:UIControlStateNormal];
    [_trainBut setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    v3.shimmering=YES;
    /////////////////////////今日电影
    FBShimmeringView *v2=[FBShimmeringView new];
    [_greenView addSubview:v2];
    [v2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(_greenView.mas_bottom).mas_equalTo(-190);
        make.width.mas_equalTo(135);
        make.height.mas_equalTo(50);
        make.left.mas_equalTo(_greenView.mas_left).mas_equalTo(28);
    }];
    v2.contentView=self.movieBut;
    [_movieBut mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    v2.shimmering=YES;
    
    
    [_movieBut setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_movieBut setTitle:@"今日上映电影" forState:UIControlStateNormal];
    [_movieBut addTarget:self action:@selector(movie:) forControlEvents:UIControlEventTouchUpInside];
}


}
//-(void)aaaa:(NSNotification *)info
//{
    
    
 //   self.weatherText.text=info.userInfo[@"ll"];

//}

@end
