//
//  ViewController.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/4.
//  Copyright © 2015年 tarena. All rights reserved.
//
//
//#import "ViewController.h"
//#import "WeatherModel.h"
//#import "WeatherNetManager.h"
//#import <CoreLocation/CoreLocation.h>
//#import "TrainNetManager.h"
//#import "TrainModel.h"
//#import "FunNetManager.h"
//#import "FunModel.h"
//#import "TraveModel.h"
//#import "TraveNetManager.h"
////#import "UMSocial.h"
////#import "XmeetViewController.h"
////#import "XmeetNetManager.h"
//#import "CityNetManager.h"
//#import "MovieModel.h"
//#import "CinemaNetManager.h"
//#import "MovieNetManager.h"
//@interface ViewController ()<CLLocationManagerDelegate>
//@property(nonatomic,strong)TrainModel *m;
//@end
//
//@implementation ViewController
//
//- (void)viewDidLoad {
//    [super viewDidLoad];
//
////   [WeatherNetManager getDataForBaseNetManager:^(WeatherModel *model, NSError *error) {
////     NSLog(@"??=%@",model.result.future.day77.temperature);   }];
////  
//   //NSString *a=@"a";
//    //a=[a stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//   // a=[a stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
////    CLGeocoder *geocoder = [CLGeocoder new];
////    NSString *address=@"广州市海珠区";
////    [geocoder geocodeAddressString:address completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
////        for (CLPlacemark *mark in placemarks) {
////            NSLog(@"mark location %@", mark.location);
////        }
////    }];
////    
////    CLLocationManager *locationManager = [[CLLocationManager alloc] init];
////    locationManager.delegate=self;
////    locationManager.desiredAccuracy=kCLLocationAccuracyBest;
////    locationManager.distanceFilter=1000.0f;
////    [locationManager requestAlwaysAuthorization];
////    //启动位置更新
////    [locationManager startUpdatingLocation];
////    _manager = [[CLLocationManager alloc] init];
////    //定位是异步操作，当定位完成后会使用代理来通知我们
////    _manager.delegate = self;
////    //iOS8以后，定位需要用户的同意
////    //如果不写版本号判断，直接调用。 因为iOS7的手机是没有下方方法的，定位时会崩溃，原因是调用了不存在的方法
////    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0) {
////        //下方代码必须在info.plist文件中 加入对应的key 才生效
////        //key可以通过查询方法源代码的注释 来获得
////        //Authorization 授权
////        //requestAlwaysAuthorization 申请应用程序在前台和后台都可以定位
////        [_manager requestAlwaysAuthorization];
////        //requestWhenInUseAuthorization 申请当应用在前台时定位
////        [_manager requestWhenInUseAuthorization];
////    }
////    
////  __block  TrainModel *m=[TrainModel new];
////  dispatch_queue_t queue=dispatch_queue_create("SerialQueue", DISPATCH_QUEUE_SERIAL);
////        //向串行队列中 放同步任务
////        //把参数2这个任务 放入到 参数1队列中
////        dispatch_sync(queue, ^{
//////            [FunNetManager getSomeFunOnLng:@"" OnLat:@"" completionHandle:^(FunModel *model, NSError *error) {
//////                NSLog(@"mmmmmodel=%@",model);
//////                fd=model;
//////             NSLog(@"%@dadad",fd.result[0]);
//////                FunResultModel *f=fd.result[0];
//////                NSLog(@"%@hahahah",f.address);
//////            }];
////           
////        });
////        //向串行队列中发任务2
////        dispatch_sync(queue, ^{
////            NSLog(@"what2=%@",self.m.data);        });//
//////
//////
////    dispatch_queue_t queue=dispatch_queue_create("SerialQueue", DISPATCH_QUEUE_SERIAL);
////    //向串行队列中 放同步任务
////    //把参数2这个任务 放入到 参数1队列中
////    dispatch_sync(queue, ^{
////        [FunNetManager getSomeFunOnLng:@"" OnLat:@"" completionHandle:^(FunModel *model, NSError *error) {
////            NSLog(@"mmmmmodel=%@",model);
////            fd=model;
////         NSLog(@"%@dadad",fd.result[0]);
////            FunResultModel *f=fd.result[0];
////            NSLog(@"%@hahahah",f.address);
////        }];
////    });
////    //向串行队列中发任务2
////    dispatch_sync(queue, ^{
////        NSLog(@"what=%@",fd.result);
////    });
// //   [self performSelectorOnMainThread:@selector(haha) withObject:nil waitUntilDone:NO];
//    
// //   NSLog(@"daoma?%@",self.m.data.trainList[0]);
////    [TrainNetManager getBaseModle:@"1.0" From:@"广州" To:@"钦州" Date:@"2015-12-09" completionHandle:^(TrainModel *modle, NSError *error) {
////        //  NSLog(@"%@dddddd",modle.data);
////        NSLog(@"先到");self.m=modle;
////        NSLog(@"先到2");
////        TrainListModel *md=modle.data.trainList[1];
////        NSLog(@"%@hahda",md.to);
////    }];
////  [TraveNetManager getTraveDataFoQuery:@"圆明园" Page:@"1" completionHandle:^(TraveModel *modle, NSError *error) {
////      TraveDataBookModel*bo=modle.data.books[2];
////      NSLog(@"nani=%@,%@",bo.text,bo.title);
////  }];
////    
//    
//}
//-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(nonnull NSArray<CLLocation *> *)locations
//{
//   // CLLocation *c=[locations objectAtIndex:0];
////纬度c.coordinate.latitude
//   // 经度c.coordinate.longitude
//}
//- (IBAction)sa:(id)sender {
////    [ UMSocialSnsService presentSnsIconSheetView:self appKey:@"5632e6b6e0f55a6bbc0000a5" shareText:@"没什么" shareImage:[UIImage imageNamed:@"icon"] shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToWechatSession,UMShareToQQ,UMShareToSms,UMShareToEmail,UMShareToWechatTimeline,nil] delegate:self];
////    
//  //  [self haha];
//    
////    [CityNetManager getCityList:^(CityName *model, NSError *error) {
////        CityNameListModel *city=model.result[1];
////        NSLog(@"????aa%@,%@",city.cityName,city.iid);
////    }];
//    
////    [CinemaNetManager getCinemaForLatitude:@"31.30947" Longitude:@"120.6003" Radius:@"3000" CompletionHandle:^(CinemaModel *modle, NSError *error) {
////        CinemaListModel *m=modle.result[1];
////        
////        NSLog(@"hah%@,%@,%@",m.address,m.cityName,m.cinemaName);
////    }];
////    
////[MovieNetManager getTodayMovieForCityID:@"2" completionHandle:^(TodayMovie *modle, NSError *error) {
////    TodayMovieList *list=modle.result[2];
////    NSLog(@"%@,%@,%@",list.movieName,list.movieId,list.picUrl);
////    
////}];
//  
//    
//    
//    
//}
//-(void)haha{
//    
////    XmeetViewController * xmeet = [[XmeetViewController alloc]init];
////    [xmeet setShowType:YES];
////    UINavigationController * nav = [[UINavigationController alloc]initWithRootViewController:xmeet];
////    [self presentViewController:nav animated:YES completion:nil];
////    
////    XmeetViewController *xmeet = [[XmeetViewController alloc]init];
////    [self.navigationController pushViewController:xmeet animated:YES];
////    [XmeetNetManager getXmeetModelForNickname:@"什么" XmeetRoomId:@"id" completionHandle:^(XmeetModel *model, NSError *error) {
////        
////        NSLog(@"????????%@",model);
////    }];
//    
//}




//@end
