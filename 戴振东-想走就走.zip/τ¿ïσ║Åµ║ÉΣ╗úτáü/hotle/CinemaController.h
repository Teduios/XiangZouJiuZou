//
//  CinemaController.h
//  hotle
//
//  Created by apple-jd31 on 15/11/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CinemaViewModel.h"
@interface CinemaController : UIViewController
@property(nonatomic,strong)CinemaViewModel *data;
@property(nonatomic,strong)NSMutableArray *arr;
@end
