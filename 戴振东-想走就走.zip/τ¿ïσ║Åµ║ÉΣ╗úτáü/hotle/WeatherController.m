//
//  WeatherController.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/9.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "WeatherController.h"
#import "WeatherViewModel.h"
#import "futrueWeatherCell.h"
#import "WeatherModel.h"
#import <Masonry.h>

@interface WeatherController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)WeatherViewModel *model;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *temp;
@property (weak, nonatomic) IBOutlet UILabel *humidity;

@property (weak, nonatomic) IBOutlet UILabel *dateG;
@property (weak, nonatomic) IBOutlet UILabel *wind;
@property (weak, nonatomic) IBOutlet UILabel *datagg;

@property(nonatomic,strong)NSTimer *time;
@end

@implementation WeatherController
-(WeatherViewModel *)model
{
    if (!_model) {
        _model=[[WeatherViewModel alloc]initWithCityName:_cityName];
    }return _model;
}
- (IBAction)return0:(id)sender {
  
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
   
   
        [self.model refData:^(NSError *error){
        }];
 self.time=[NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(haha:) userInfo:nil repeats:YES];
 //   NSLog(@"%@",_cityName);
    _cityname.text=_cityName;

    
}
-(void)goback:(UIBarButtonItem*)item{

    [self.navigationController popViewControllerAnimated:YES];

}

-(void)haha:(NSTimer*)time
{
    self.datagg.text=[NSString stringWithFormat:@"更新:%@",[self.model getSkTime]];
   
        self.temp.text=[self.model getSkTemp];
        self.humidity.text=[self.model getSkHumidity];
        self.wind.text=[[self.model getSkWind]stringByAppendingString:[NSString stringWithFormat:@"&%@",[self.model getSkWindS]]];
    if (self.model.model!=nil) {
        [_tableView reloadData];//NSLog(@"""dddd");
    }
    
   
    if (self.model.model!=nil) {
         [self.time invalidate];
    }
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
 // NSLog(@"nnnnn%ld",self.model.futrueWeather.count);
    return self.model.futrueWeather.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    futrueWeatherCell *cell=[tableView dequeueReusableCellWithIdentifier:@"Ce" forIndexPath:indexPath];
  WeatherDaysModel *day=self.model.futrueWeather[indexPath.row];
    cell.date.text=[NSString stringWithFormat:@"%@-%@-%@",[day.date substringToIndex:4],[[day.date substringToIndex:6]substringFromIndex:4],[day.date substringFromIndex:6]];
    cell.weather.text=day.weather;
    cell.week.text=day.week;
    cell.temperature.text=day.temperature;//NSLog(@"ffff");
    if ([day.weather isEqualToString:@"多云"]) {
        cell.image.image=[UIImage imageNamed:@"多云"];
    }else if([day.weather isEqualToString:@"大雨"]){
        cell.image.image=[UIImage imageNamed:@"大雨"];
    }else if([day.weather isEqualToString:@"阴"]){
        cell.image.image=[UIImage imageNamed:@"阴"];
    }else if([day.weather isEqualToString:@"小雪"]){
        cell.image.image=[UIImage imageNamed:@"雪"];
    }
    else if([day.weather isEqualToString:@"多云转晴"]){
        cell.image.image=[UIImage imageNamed:@"多云转晴"];
    }
    else if([day.weather isEqualToString:@"小雨"]){
        cell.image.image=[UIImage imageNamed:@"大雨"];
    }else if([day.weather isEqualToString:@"大雨"]){
        cell.image.image=[UIImage imageNamed:@"大雨"];
    }else if([day.weather isEqualToString:@"晴"]){
        cell.image.image=[UIImage imageNamed:@"晴"];
    }else if([day.weather isEqualToString:@"雷阵雨"]){
        cell.image.image=[UIImage imageNamed:@"雷阵雨"];
    }else{
        NSArray *arr=@[@"多云",@"大雨",@"阴",@"雪",@"大雨",@"雷阵雨",@"晴"];
        for (NSString *a in arr) {
            NSRange r=[day.weather rangeOfString:a];
            if (r.length>0) {
                cell.image.image=[UIImage imageNamed:a];continue;
            }
        }
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{[tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.view endEditing:YES];

}

@end
