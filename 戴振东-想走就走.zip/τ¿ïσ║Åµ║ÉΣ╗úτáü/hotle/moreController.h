//
//  moreController.h
//  hotle
//
//  Created by apple-jd31 on 15/11/17.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface moreController : UIViewController
@property(nonatomic,strong)NSString *url;
@end
