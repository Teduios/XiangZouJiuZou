//
//  WeatherModel.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/4.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "WeatherModel.h"

@implementation WeatherModel
-(NSDictionary *)speciaModel
{
    return @{@"result":@"WeatherResultModel"};//把JSON数据里的result换成自己定义的类，然后再到BaseModel里解析

}
@end
@implementation WeatherResultModel
-(NSDictionary *)speciaModel
{
    return @{@"sk":@"WeatherResultSKModel",@"future":@"WeatherFutureModel"};
}

@end

@implementation WeatherResultSKModel
-(NSDictionary *)speciaKey
{
    return @{@"wind_direction":@"windDirection",@"wind_strength":@"windStrength"};
}//把特殊变量名和自己定义的变量名放到一个KEY：VALUE里，方便解析时JSON数据时调包


@end
@implementation WeatherFutureModel
-(NSString *)getDate
{
    NSDate *da=[NSDate dateWithTimeIntervalSinceNow:0];
    NSDateFormatter *s=[[NSDateFormatter alloc]init];
    s.dateFormat=@"yyyyMMdd";
    return [s stringFromDate:da];
}
-(NSString *)day1{
    return [@"day_"stringByAppendingString:[self getDate]];
}
-(NSString *)day2
{
    return [NSString stringWithFormat:@"day_%ld",[[self getDate]integerValue]+1];
}
-(NSString *)day3
{
    return [NSString stringWithFormat:@"day_%ld",[[self getDate]integerValue]+2];
}
-(NSString *)day4
{
    return [NSString stringWithFormat:@"day_%ld",[[self getDate]integerValue]+3];
}
-(NSString *)day5
{
    return [NSString stringWithFormat:@"day_%ld",[[self getDate]integerValue]+4];
}
-(NSString *)day6
{
    return [NSString stringWithFormat:@"day_%ld",[[self getDate]integerValue]+5];
}
-(NSString *)day7
{
    return [NSString stringWithFormat:@"day_%ld",[[self getDate]integerValue]+6];
}
-(NSDictionary *)speciaModel
{
    
    return @{@"day11":@"WeatherDaysModel",@"day22":@"WeatherDaysModel",@"day33":@"WeatherDaysModel",@"day44":@"WeatherDaysModel",@"day55":@"WeatherDaysModel",@"day66":@"WeatherDaysModel",@"day77":@"WeatherDaysModel"};
    
}
-(NSDictionary *)speciaKey
{
    
    return @{self.day1:@"day11",self.day2:@"day22",self.day3:@"day33",self.day4:@"day44",self.day5:@"day55",self.day6:@"day66",self.day7:@"day77"};
}

@end
@implementation WeatherDaysModel


@end

