//
//  FunCell.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/10.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FunCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *starts;
@property (weak, nonatomic) IBOutlet UILabel *badRemarks;
@property (weak, nonatomic) IBOutlet UILabel *goodRemaks;
@property (weak, nonatomic) IBOutlet UILabel *adress;
@property (weak, nonatomic) IBOutlet UILabel *tags;
@property (weak, nonatomic) IBOutlet UILabel *cityAndArea;
@property (weak, nonatomic) IBOutlet UILabel *phone;
@property (weak, nonatomic) IBOutlet UILabel *navigation;
@property (weak, nonatomic) IBOutlet UIImageView *photo;
@property (weak, nonatomic) IBOutlet UILabel *nearByShop;
@property (weak, nonatomic) IBOutlet UILabel *avgPrice;





@end
