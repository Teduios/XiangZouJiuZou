//
//  MovieNetManager.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/8.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "MovieNetManager.h"

@implementation MovieNetManager
+(id)getTodayMovieForCityID:(NSString *)ID completionHandle:(void (^)(TodayMovie *, NSError *))completionHandle
{
    NSString *url=[NSString stringWithFormat:@"http://v.juhe.cn/movie/movies.today?key=e9421b9d9c66bc95ff7696dbc9e04a60&cityid=%@",ID];
    return [self getDataForNet:url completiaonHandle:^(NSData *data, NSError *error) {
        TodayMovie *movie=[TodayMovie input:data];
        completionHandle(movie,error);
    }];
    
}

@end
