//
//  WeatherViewModel.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/9.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WeatherModel.h"
#import "WeatherNetManager.h"
@interface WeatherViewModel : NSObject
-(instancetype)initWithCityName:(NSString *)cityName;
@property(nonatomic,strong)NSString *cityName;
@property(nonatomic,strong)WeatherModel *model;
-(NSString *)getSkTemp;
-(NSString *)getSkWind;
-(NSString *)getSkWindS;
-(NSString *)getSkHumidity;
-(NSString *)getSkTime;
@property(nonatomic,strong)NSArray *futrueWeather;

-(void)refData:(void(^)(NSError *error))completion;
@end
