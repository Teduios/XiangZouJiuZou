//
//  WeatherNetManager.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/5.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "WeatherNetManager.h"

@implementation WeatherNetManager

+(id)getDataForCityName:(NSString *)cityName completionHandle:(void (^)(WeatherModel *, NSError *))completion
{
    NSString *name=[cityName stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    return [self getDataForNet:[NSString stringWithFormat:@"http://v.juhe.cn/weather/index?format=1&cityname=%@&key=b8ec29087ea356d64086e34ee77f11a2",name] completiaonHandle:^(NSData *data, NSError *error) {
        WeatherModel *k=[WeatherModel input:data];
        completion(k,error);
        
    }];


}



@end
