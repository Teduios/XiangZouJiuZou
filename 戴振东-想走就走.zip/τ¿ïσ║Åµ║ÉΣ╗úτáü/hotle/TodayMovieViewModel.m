//
//  TodayMovieViewModel.m
//  hotle
//
//  Created by apple-jd31 on 15/11/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TodayMovieViewModel.h"
#import <CoreLocation/CoreLocation.h>
@implementation TodayMovieViewModel
-(instancetype)initWithLongitude:(NSString *)longitude Latitude:(NSString *)latitude
{
    if (self=[super init]) {
        _longitude=longitude;_latitude=latitude;
    }return self;
}
-(TodayMovie *)model
{
    if (!_model) {
        _model=[[TodayMovie alloc]init];
    }return _model;

}
-(void)GetCityModel
{
//    CLGeocoder *g=[CLGeocoder new];
//    [g reverseGeocodeLocation:[[CLLocation alloc]initWithLatitude:_latitude.floatValue longitude:_longitude.floatValue] completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
//        for (CLPlacemark *make in placemarks) {
//            _CityID=make.name; }}];
//    [CityNetManager getCityList:^(CityName *model, NSError *error) {
//        for (_cityList in model.result) {
//            NSRange range=[_CityID rangeOfString:_cityList.cityName];
//            if (range.length>=2) {
//                _CityID=@"1";
//            }
//            
//        }
//    }];
    NSLog(@"11111111");
    self.cinema=[[CinemaViewModel alloc]initWithlongitude:_longitude Latitude:_latitude];
    //self.cinema.model添加观察者会蹦因为一会赋值model会改变指针
   [self.cinema addObserver:self forKeyPath:@"model.error2" options:NSKeyValueObservingOptionNew context:nil];
    
    [self.cinema getData];
  //  self.time=[NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(haha:) userInfo:nil repeats:YES];
   
}
-(void)haha:(NSTimer *)time
{
   
    if (![self.cinema.model.error isEqualToString:@"1"]) {
               CinemaListModel *list=self.cinema.model.result.firstObject;
         NSLog(@"?????222222??,%@,%@,%@",_longitude,list.cityName,list.iid);
        _CityID=[NSString stringWithFormat:@"%@",list.iid];
        [MovieNetManager getTodayMovieForCityID:@"1" completionHandle:^(TodayMovie *modle, NSError *error) {
            NSLog(@"%@aaaaaaaaaa",_CityID);
            
            self.model=modle;}];[self.time invalidate]; }
    
}

-(void)getData
{
    [self GetCityModel];
   NSLog(@"?????????????%@,%@,,%@",_CityID,_longitude,_latitude);

}
-(NSString *)getMoivePicURL:(NSInteger)row
{
   _list=_model.result[row];
    return _list.picUrl;
}
-(NSString *)getMovieID:(NSInteger)row
{
    _list=_model.result[row];
    return _list.picUrl;
}
-(NSString *)getMovieName:(NSInteger)row
{
    _list=_model.result[row];
    return _list.movieName;
}
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    if ([object isKindOfClass:[CinemaViewModel class]]&&(![self.cinema.model.error isEqualToString:@"1"])) {
        [MovieNetManager getTodayMovieForCityID:@"1" completionHandle:^(TodayMovie *modle, NSError *error) {
            NSLog(@"%@a?aaaaaaaaa%@,,%@",_CityID,self.cinema.model.error,self.cinema.model.error2);
            self.model=modle;}];
        [self.cinema removeObserver:self forKeyPath:@"model.error2"];
    }
NSLog(@"%@a?aaaaaaaaa%@",_CityID,self.cinema.model.error);
    
    
    
}


@end
