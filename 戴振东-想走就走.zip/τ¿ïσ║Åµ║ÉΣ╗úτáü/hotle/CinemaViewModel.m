//
//  CinemaViewModel.m
//  hotle
//
//  Created by apple-jd31 on 15/11/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "CinemaViewModel.h"
#define ha CinemaListModel *list=_model.result[row];return list.
@implementation CinemaViewModel
-(CinemaModel *)model
{
    if (!_model) {
        _model=[[CinemaModel alloc]init];
        NSLog(@"...");
    }return _model;

}
-(instancetype)initWithlongitude:(NSString *)longitude Latitude:(NSString *)latitude
{
    if (self=[super init]) {
        _longitude=longitude;_latitude=latitude;
    }return self;
}
-(void)getData
{
    NSLog(@"%@,,??,%@",_latitude,_longitude);
    
    [CinemaNetManager getCinemaForLatitude:_latitude Longitude:_longitude Radius:@"1500" CompletionHandle:^(CinemaModel *modle, NSError *error) {
   NSLog(@"%@aaaaaaaaaa%@",modle,self.model);
    self.model=modle;
       
    
    }];
}
-(NSString *)getAdress:(NSInteger)row
{
    _list=_model.result[row];
    return _list.address;
}
-(NSString *)getCinemaName:(NSInteger)row
{
    _list=_model.result[row];

    return _list.cinemaName;
}
-(NSNumber *)getCityID:(NSInteger)row
{
    ha iid;
}
-(NSString *)getCityName:(NSInteger)row
{
    ha cityName;
}
-(NSNumber *)getDistance:(NSInteger)row
{
    ha distance;
}
-(NSString *)getTelephone:(NSInteger)row
{
    ha telephone;
}
-(NSString *)getTrafficRoutes:(NSInteger)row
{
    ha trafficRoutes;
}

@end
