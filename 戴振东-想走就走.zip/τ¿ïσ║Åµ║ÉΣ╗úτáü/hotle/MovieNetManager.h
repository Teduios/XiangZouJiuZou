//
//  MovieNetManager.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/8.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "MovieModel.h"
@interface MovieNetManager : BaseNetManager
+(id)getTodayMovieForCityID:(NSString *)ID completionHandle:(void(^)(TodayMovie *modle,NSError *error))completionHandle;

@end
