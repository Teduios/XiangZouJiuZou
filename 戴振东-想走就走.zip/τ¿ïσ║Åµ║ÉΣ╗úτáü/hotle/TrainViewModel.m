//
//  TrainViewModel.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/9.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TrainViewModel.h"

@implementation TrainViewModel
-(TrainModel *)modle
{
    if (!_modle) {
        _modle=[[TrainModel alloc]init];
    }return _modle;
}
-(instancetype)initWithForm:(NSString *)form Date:(NSString *)date To:(NSString *)to
{
    if (self=[super init]) {
        self.from=form;self.date=date;self.to=to;
    }
    return self;
}
-(void)getData{
[TrainNetManager getBaseModle:@"1.0" From:self.from To:self.to Date:self.date completionHandle:^(TrainModel *modle, NSError *error) {
    self.modle=modle;
}];
}
-(NSString *)getStartTime:(NSInteger)row{
    TrainListModel *list=self.modle.data.trainList[row];
    return list.startTime;
}
-(NSString *)getTo:(NSInteger)row{
    TrainListModel *list=self.modle.data.trainList[row];return list.to;

}
-(NSString *)getTrainNo:(NSInteger)row{
    TrainListModel *list=self.modle.data.trainList[row];return list.trainNo;

}
-(NSString *)getTrainType:(NSInteger)row{
 TrainListModel *list=self.modle.data.trainList[row];return list.trainType;
}
-(NSString *)getDuration:(NSInteger)row{
 TrainListModel *list=self.modle.data.trainList[row];return list.duration;

}
-(NSString *)getFrom:(NSInteger)row
{
    TrainListModel *list=self.modle.data.trainList[row];return list.from;
}
-(TrainListSeatinfosModel *)getSeatinfos1{
 TrainListModel *list=self.modle.data.trainList[0];
    return list.seatInfos.firstObject;
}
-(TrainListSeatinfosModel *)getSeatinfos2
{
    TrainListModel *list=self.modle.data.trainList[0];
    return list.seatInfos.lastObject;
}
-(NSString *)getEndTime:(NSInteger)row
{
    TrainListModel *list=self.modle.data.trainList[row];return list.endTime;
}

@end
