//
//  CinemaViewModel.h
//  hotle
//
//  Created by apple-jd31 on 15/11/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MovieModel.h"
#import "CinemaNetManager.h"

#define cc -(NSString*)
#define dd :(NSInteger)row;
@interface CinemaViewModel : NSObject
-(instancetype)initWithlongitude:(NSString *)longitude Latitude:(NSString *)latitude;
-(void)getData;
@property(nonatomic,strong)NSString *city;
@property(nonatomic,strong)CinemaListModel *list;
@property(nonatomic,strong)CinemaModel *model;
@property(nonatomic,strong)NSString *latitude;
@property(nonatomic,strong)NSString *longitude;
-(NSNumber *)getCityID:(NSInteger)row;
cc getCityName dd
cc getCinemaName dd
cc getAdress dd
cc getTelephone dd
cc getTrafficRoutes dd
-(NSNumber *)getDistance dd




@end
