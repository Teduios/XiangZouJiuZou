//
//  TodayMovieCell.h
//  hotle
//
//  Created by apple-jd31 on 15/11/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TodayMovieCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *movieName;
@property (weak, nonatomic) IBOutlet UIImageView *moviePituce;

@property (weak, nonatomic) IBOutlet UIImageView *moviePic;

@end
