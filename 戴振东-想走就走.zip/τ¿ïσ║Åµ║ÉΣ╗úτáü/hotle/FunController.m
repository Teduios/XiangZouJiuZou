//
//  FunController.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/10.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "FunController.h"
#import "FunCell.h"
#import "FunModel.h"
#import "FunViewModel.h"
#import <CoreLocation/CoreLocation.h>
#import <UIImageView+WebCache.h>
@interface FunController ()<UITableViewDataSource,UITableViewDelegate,CLLocationManagerDelegate>
@property(nonatomic,strong)FunViewModel *data;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
//@property(nonatomic,strong)NSTimer *time;
@property(nonatomic,strong)CLLocationManager *location;
@property(nonatomic,strong)NSString *lng;
@property(nonatomic,strong)NSString *lat;
//@property(nonatomic)NSInteger idx;
@end

@implementation FunController
-(CLLocationManager *)location
{
    if (!_location) {
        _location=[[CLLocationManager alloc]init];
        _location.delegate=self;
        if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0) {
                    //下方代码必须在info.plist文件中 加入对应的key 才生效
                    //key可以通过查询方法源代码的注释 来获得
                    //Authorization 授权
                    //requestAlwaysAuthorization 申请应用程序在前台和后台都可以定位
                    [_location requestAlwaysAuthorization];
                   // requestWhenInUseAuthorization 申请当应用在前台时定位
                    [_location requestWhenInUseAuthorization];
             _location.desiredAccuracy=kCLLocationAccuracyBest;
                _location.distanceFilter=1000.0f;
                [_location requestAlwaysAuthorization];
                //启动位置更新
                [_location startUpdatingLocation];
        }
    }
    return _location;
}
-(FunViewModel *)data
{
    if (!_data) {
        _data=[[FunViewModel alloc]initWithLongitude:self.lng Lotude:self.lat];
    }return _data;
}
- (void)viewDidLoad {
    [super viewDidLoad];

        CLGeocoder *geocoder = [CLGeocoder new];
        NSString *address=@"广州市海珠区";
        [geocoder geocodeAddressString:address completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
            for (CLPlacemark *mark in placemarks) {
                NSLog(@"mark location %f,%f", mark.location.coordinate.latitude,mark.location.coordinate.longitude);
             //   self.lat=[NSString stringWithFormat:@"%f",23.103131];
            //    self.lng=[NSString stringWithFormat:@"%f",113.262008];
                }
        }];
    self.lat=[NSString stringWithFormat:@"%f",23.103131];
    self.lng=[NSString stringWithFormat:@"%f",113.262008];
    
    [self.data getData];
   
    [self.data addObserver:self forKeyPath:@"model.error2" options:NSKeyValueObservingOptionNew context:nil];
  //self.time=[NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(hh:) userInfo:nil repeats:YES];
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
      return self.data.model.result.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FunCell *cell=[tableView dequeueReusableCellWithIdentifier:@"aaaaa" forIndexPath:indexPath];
    cell.navigation.text=[self.data getNavigation:indexPath.row];
    cell.tags.text=[self.data getTags:indexPath.row];
    cell.phone.text=[self.data getTags:indexPath.row];
    cell.adress.text=[self.data getAddress:indexPath.row];
    cell.cityAndArea.text=[[self.data getCity:indexPath.row]stringByAppendingFormat:@"&%@",[self.data getArea:indexPath.row]];
    cell.badRemarks.text=[@"差评" stringByAppendingFormat:@":%@",[self.data getGood_remarks:indexPath.row]==nil?@"0":[self.data getGood_remarks:indexPath.row]];
    cell.goodRemaks.text=[@"好评" stringByAppendingFormat:@":%@",[self.data getBadRemarks:indexPath.row]];
    cell.nearByShop.text=[self.data getNearbyShops:indexPath.row];
    cell.name.text=[self.data getName:indexPath.row];
    cell.starts.text=[[self.data getStars:indexPath.row]stringByAppendingString:@"星级"];
    [cell.photo sd_setImageWithURL:[NSURL URLWithString:[self.data getPhotos:indexPath.row]]];
   
    return cell;

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
    CLLocation *l=[locations objectAtIndex:0];
    self.lng=[NSString stringWithFormat:@"%f",l.coordinate.longitude];
    self.lat=[NSString stringWithFormat:@"%f",l.coordinate.latitude];
    
}
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    if ((![self.data.model.error isEqualToString:@"1"]&&[object isKindOfClass:[FunViewModel class]])) {
        dispatch_async(dispatch_get_main_queue(), ^{
           [self.tableView reloadData];
        });
        
        
       
    }
    
}
-(void)dealloc
{
    [self.data removeObserver:self forKeyPath:@"model.error2"];

}
//-(void)hh:(NSTimer *)time
//{if ((![self.data.model.error isEqualToString:@"1"])&&_idx<5) {
//    [self.tableView reloadData];
//   // NSLog(@"%@,,,,%ld",[self.data getNavigation:0],self.data.model.result.count);
//    [self.time invalidate];_idx=0;
//   // NSLog(@"vvv");
//}
//    
//    _idx++;
//}


@end
