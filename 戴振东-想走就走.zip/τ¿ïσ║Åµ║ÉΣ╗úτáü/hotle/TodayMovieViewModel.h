//
//  TodayMovieViewModel.h
//  hotle
//
//  Created by apple-jd31 on 15/11/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MovieModel.h"
#import "MovieNetManager.h"
#import "CityNetManager.h"
#import "CinemaViewModel.h"
#import "CinemaNetManager.h"
@interface TodayMovieViewModel : NSObject
-(instancetype)initWithLongitude:(NSString*)longitude Latitude:(NSString *)latitude;
-(void)getData;
@property(nonatomic,strong)NSString *CityID;
@property(nonatomic,strong)TodayMovie *model;
//@property(nonatomic,strong)CityName *cityName;
//@property(nonatomic,strong)CityNameListModel *cityList;
@property(nonatomic,strong)NSString *longitude;
@property(nonatomic,strong)NSString *latitude;
@property(nonatomic,strong)TodayMovieList *list;
@property(nonatomic,strong)CinemaViewModel *cinema;
@property(nonatomic,strong)NSTimer *time;
-(NSString *)getMovieID:(NSInteger)row;
-(NSString *)getMovieName:(NSInteger)row;
-(NSString *)getMoivePicURL:(NSInteger)row;


@end
