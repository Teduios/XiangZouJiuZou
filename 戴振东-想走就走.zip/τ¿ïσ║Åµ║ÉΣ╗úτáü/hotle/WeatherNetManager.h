//
//  WeatherNetManager.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/5.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "WeatherModel.h"
@interface WeatherNetManager : BaseNetManager

+(id)getDataForCityName:(NSString *)cityName completionHandle:(void(^)(WeatherModel *model,NSError *error))completion;

@end
