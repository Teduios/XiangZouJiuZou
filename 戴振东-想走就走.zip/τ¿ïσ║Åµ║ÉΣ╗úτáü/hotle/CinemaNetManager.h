//
//  CinemaNetManager.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/8.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "MovieModel.h"
@interface CinemaNetManager : BaseNetManager

//http://v.juhe.cn/movie/cinemas.local?key=dc59ddb41521c1c5912e7c57bfbe3116&dtype=json&lat=31.30947&lon=120.6003&radius=2000
+(id)getCinemaForLatitude:(NSString *)latitude Longitude:(NSString *)longitude Radius:(NSString *)radius CompletionHandle:(void(^)(CinemaModel *modle,NSError *error))completionHandle;
@end
