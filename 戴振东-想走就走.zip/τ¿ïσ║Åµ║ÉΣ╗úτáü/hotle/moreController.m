//
//  moreController.m
//  hotle
//
//  Created by apple-jd31 on 15/11/17.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "moreController.h"
#import <Masonry.h>
@interface moreController ()<UIWebViewDelegate>

@end

@implementation moreController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIWebView *web=[[UIWebView alloc]init];
    web.delegate=self;
    [self.view addSubview:web];
    [web mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
   NSURLRequest *re =[NSURLRequest requestWithURL:[NSURL URLWithString:self.url]];
  //  NSLog(@"%%%%%%%%%%%%%%%%%%%%,%@",self.url);
    [web loadRequest:re];
    [[UINavigationBar appearance]setBackgroundImage:[UIImage imageNamed:@"五彩3"] forBarMetrics:UIBarMetricsDefault];    

}



@end
