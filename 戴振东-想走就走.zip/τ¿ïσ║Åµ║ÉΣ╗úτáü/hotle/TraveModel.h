//
//  TraveModel.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/7.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseModel.h"
@class TraveDataModel;
@class TraveDataBookModel;
@interface TraveModel : BaseModel
@property(nonatomic,strong)TraveDataModel *data;
@property(nonatomic,strong)NSString *error;
@end
@interface TraveDataModel : BaseModel
@property(nonatomic,strong)NSString *error;
@property(nonatomic,strong)NSMutableArray *books;
@end
@interface TraveDataBookModel : BaseModel
@property(nonatomic,strong)NSString *bookUrl;//详情
@property(nonatomic,strong)NSString *title;//标题
@property(nonatomic,strong)NSString *headImage;//大图
@property(nonatomic,strong)NSString *userHeadImg;//图标
@property(nonatomic,strong)NSString *startTime;//开始时间
@property(nonatomic,strong)NSNumber *routeDays;//停留时间
@property(nonatomic,strong)NSString *text;//途经
@end