//
//  BaseModel.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/4.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseModel.h"
#import "WeatherModel.h"
@implementation BaseModel

-(NSDictionary *)speciaKey{

    return nil;
}
-(NSDictionary *)speciaModel{
    
    return nil;
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
}
-(id)valueForUndefinedKey:(NSString *)key
{
return @"2";
}
+(id)input:(id)inputValue
{
    id Obj=inputValue;
    if ([Obj isKindOfClass:[NSArray class]]) {
        Obj= [self inputArr:inputValue];//NSLog(@"this base model arr")  ;
        return Obj;
    }
    if ([Obj isKindOfClass:[NSDictionary class]]) {
        Obj=[self inputDic:inputValue];//NSLog(@"this base model dic");
        return Obj;
    }
   
    return Obj;
}

+(NSArray*)inputArr:(id)inputArr
{
    NSMutableArray *NewArr=[NSMutableArray new];
    for (id inputObj in inputArr) {
       // NSLog(@"跟踪1");
        id Output=[self inputDic:inputObj];
         [NewArr addObject:Output];//NSLog(@"跟踪2");
    }
    return NewArr;
}
+(id)inputDic:(id)inputDic
{
    
    id model=[self new];
  // NSLog(@"I M dic");
    NSDictionary *speciaKey=[model speciaKey];
    NSDictionary *speciaModel=[model speciaModel];
    
    [inputDic enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        if ([speciaKey objectForKey:key]) {
            key=speciaKey[key];//调包
        }
        if ([speciaModel objectForKey:key]) {
         //  NSLog(@"spModel=%@,key=%@,self=%@",speciaModel,key,self);
            Class class=NSClassFromString(speciaModel[key]);
          //  NSLog(@"class=%@,obj=%@,,,%@",class,obj,speciaModel[key]);
            obj=[class input:obj];
          //  NSLog(@"OBJ=%@",obj);
        }
    
        if ((![obj isKindOfClass:[NSNull class]])&&obj!=nil){
            if ([obj isKindOfClass:[NSArray class]]) {
                NSArray *a=[NSArray arrayWithArray:obj];
                if (a.count==0) {
                  [model setValue:@"1" forKey:@"error"];
        //            NSLog(@"进来？");
                } else {[model setValue:obj forKey:key];}
            }else{
         //    NSLog(@"%@dad",inputDic[key]);
                [model setValue:obj forKey:key];
                
                if (![[model valueForKey:@"error"] isEqualToString:@"1"]) {
                    [model setValue:@"0" forKey:@"error"];
                }
                
                [model setValue:@"0" forKey:@"error2"];
                
        //     NSLog(@"key=%@,value=%@,model=%@",key,obj,model);
       }
        }else {
   // NSLog(@"44444444key=%@,value=%@,model=%@",key,obj,model);
                
            [model setValue:@"1" forKey:@"error"];}
  
            
        }];
  //  NSLog(@"model=%@",model);
    
    
    return model;
}




@end
