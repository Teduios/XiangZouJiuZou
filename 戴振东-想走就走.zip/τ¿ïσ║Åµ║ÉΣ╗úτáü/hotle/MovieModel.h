//
//  MovieModel.h
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/8.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseModel.h"
//http://v.juhe.cn/movie/cinemas.local?key=dc59ddb41521c1c5912e7c57bfbe3116&dtype=json&lat=31.30947&lon=120.6003&radius=2000
@class CinemaListModel;
@interface CinemaModel : BaseModel

@property(nonatomic,strong)NSString *error2;
@property(nonatomic,strong)NSMutableArray *result;
@property(nonatomic,strong)NSString *error;
@end
@interface CinemaListModel : BaseModel
@property(nonatomic,strong)NSNumber *iid;//城市id
@property(nonatomic,strong)NSString *cityName;//城市名
@property(nonatomic,strong)NSString *cinemaName;//影院名称
@property(nonatomic,strong)NSString *address;//地址
@property(nonatomic,strong)NSString *telephone;//
@property(nonatomic,strong)NSString *latitude;//经度
@property(nonatomic,strong)NSString *longitude;//纬度
@property(nonatomic,strong)NSString *trafficRoutes;//交通路线
@property(nonatomic,strong)NSNumber *distance;//大概距离
@end
//http://v.juhe.cn/movie/citys?key=dc59ddb41521c1c5912e7c57bfbe3116
@class CityNameListModel;
@interface CityName :BaseModel
@property(nonatomic,strong)NSString *error;

@property(nonatomic,strong)NSMutableArray *result;
@end
@interface CityNameListModel : BaseModel
@property(nonatomic,strong)NSString *iid;//城市id
@property(nonatomic,strong)NSString *cityName;//城市名
@property(nonatomic,strong)NSString *cityPre;//城市前缀
@property(nonatomic,strong)NSString *cityPinyin;//城市拼音
@property(nonatomic,strong)NSString *cityShort;//城市短称
@property(nonatomic,strong)NSString *count;//影院数量

@end
//http://v.juhe.cn/movie/movies.today?key=dc59ddb41521c1c5912e7c57bfbe3116&cityid=3
@class TodayMovieList;
@interface TodayMovie : BaseModel
@property(nonatomic,strong)NSString *error2;
@property(nonatomic,strong)NSMutableArray *result;
@property(nonatomic,strong)NSString *error;
@end
@interface TodayMovieList : BaseModel
@property(nonatomic,strong)NSString *movieId;
@property(nonatomic,strong)NSString *movieName;
@property(nonatomic,strong)NSString *picUrl;

@end
