//
//  TrainNetManager.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/6.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TrainNetManager.h"

@implementation TrainNetManager

+(id)getBaseModle:(NSString *)version From:(NSString *)from To:(NSString *)to Date:(NSString *)date completionHandle:(void (^)(TrainModel *model, NSError *error))completionHandle{
 //NSString *httpUrl = @"http://apis.baidu.com/qunar/qunar_train_service/s2ssearch?";
//    NSString *F=[from stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    NSString *T=[to stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
   // NSString *path=[httpUrl stringByAppendingString:[NSString stringWithFormat:@"version=1.0&from=上海&to=北京&date=2015-09-01&apikey=66b69f95adecd087bb73755538f9142a"]];
//    NSString *p=[path stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    NSLog(@"%@",p);
//    
//    return [self getDataForNet:p completiaonHandle:^(NSData *data, NSError *error) {
//        NSLog(@"data=%@,path=%@",data,path);
//        completionHandle([TrainModel input:data],error);
//    }];
  
    NSString *httpUrl = @"http://apis.baidu.com/qunar/qunar_train_service/s2ssearch";
    NSString *httpArg = [NSString stringWithFormat:@"version=1.0&from=%@&to=%@&date=%@",from,to,date];
    NSString *urlStr = [[NSString alloc]initWithFormat: @"%@?%@", httpUrl, httpArg];
    NSString *d=[urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url = [NSURL URLWithString:d];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL: url cachePolicy: NSURLRequestUseProtocolCachePolicy timeoutInterval: 10];
    [request setHTTPMethod: @"GET"];
    [request addValue: @"66b69f95adecd087bb73755538f9142a" forHTTPHeaderField: @"apikey"];
    
    
    [NSURLConnection sendAsynchronousRequest: request queue: [NSOperationQueue mainQueue]
                           completionHandler: ^(NSURLResponse *response, NSData *data, NSError *error){
                               if (error) {
                                   NSLog(@"Httperror: %@%ld", error.localizedDescription, error.code);
                               } else {
                                                                   NSData *ds=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers|NSJapaneseEUCStringEncoding|NSJSONReadingAllowFragments|NSJSONReadingMutableLeaves|NSJSONWritingPrettyPrinted error:nil];
                            //      NSLog(@"ds=%@",ds);
                                   TrainModel *mm2=[TrainModel input:ds];
                                
                                 //  NSLog(@"m2=%@",tt.from);
                                   
                                   
                                   completionHandle(mm2,error);}
                           }];
    
    
   
    
    return nil;

}




@end
