//
//  CityNetManager.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/8.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "CityNetManager.h"

@implementation CityNetManager
+(id)getCityList:(void (^)(CityName *, NSError *))completionHandle
{
return [self getDataForNet:@"http://v.juhe.cn/movie/citys?key=dc59ddb41521c1c5912e7c57bfbe3116" completiaonHandle:^(NSData *data, NSError *error) {
    CityName *modle=[CityName input:data];
    completionHandle(modle,error);
}];


}
@end
