//
//  WeatherViewModel.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/9.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "WeatherViewModel.h"

@implementation WeatherViewModel
-(instancetype)initWithCityName:(NSString *)cityName
{
    if (self=[super init]) {
        _cityName=cityName;
    }
    return self;
}

-(NSArray *)futrueWeather
{
    _futrueWeather=[NSArray arrayWithObjects:self.model.result.future.day11,self.model.result.future.day22,self.model.result.future.day33,self.model.result.future.day44,self.model.result.future.day55,self.model.result.future.day66,self.model.result.future.day77, nil];
       // NSLog(@"hhhhhh%ld",_futrueWeather.count);
   
    return _futrueWeather;
}
-(NSString *)getSkHumidity{
    return self.model.result.sk.humidity;
}
-(NSString *)getSkTemp{
    return self.model.result.sk.temp;
}
-(NSString *)getSkTime
{
    return self.model.result.sk.time;
}
-(NSString *)getSkWind
{
    return self.model.result.sk.windDirection;
}
-(NSString *)getSkWindS
{return self.model.result.sk.windStrength;
}

-(void)refData:(void (^)(NSError *))completion
{
    [WeatherNetManager getDataForCityName:self.cityName completionHandle:^(WeatherModel *model, NSError *error) {
        self.model=model;
    }];
    
}

@end
