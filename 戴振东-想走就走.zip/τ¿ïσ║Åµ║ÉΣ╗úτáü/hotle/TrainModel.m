//
//  TrainModel.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/6.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TrainModel.h"

@implementation TrainModel

-(NSDictionary *)speciaModel{
    return @{@"data":@"TT"};
}

@end
@implementation TT
-(NSMutableArray *)trainList
{
    if (!_trainList) {
  
        _trainList=[NSMutableArray new];
    }return _trainList;
}
-(NSDictionary *)speciaModel
{
        return @{@"trainList":@"TrainListModel"};

}


@end
@implementation TrainListModel
-(NSMutableArray *)seatInfos
{
    if (!_seatInfos) {
        _seatInfos=[NSMutableArray new];
    }return _seatInfos;
}



-(NSDictionary *)speciaModel
{
    return @{@"seatInfos":@"TrainListSeatinfosModel"};
}

@end
@implementation TrainListSeatinfosModel



@end