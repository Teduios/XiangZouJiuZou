//
//  navViewController.h
//  hotle
//
//  Created by apple-jd31 on 15/11/18.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface navViewController : UINavigationController

@end
