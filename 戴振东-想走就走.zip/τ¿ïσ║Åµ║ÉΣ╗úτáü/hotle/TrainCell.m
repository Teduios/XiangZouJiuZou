//
//  TrainCell.m
//  HotleTravel
//
//  Created by apple-jd31 on 15/11/10.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TrainCell.h"

@implementation TrainCell

- (void)awakeFromNib {
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    
}

@end
